#include <stdio.h>

#include "global.h"

char ufname[40];
char bfname[40];

char tempt[100];
char tempa[100];

FILE* bfile;
FILE* ufile;

char t_username;

int maxBorrowed;