#ifndef LIBRARIAN_GUARD__H 
#define LIBRARIAN_GUARD__H

#include <stdio.h>



void librarianCLI();

void librarianMenu();

//search books by one of the three ways in the librarian system
void librarianSearch();


#endif