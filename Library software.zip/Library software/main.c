#define _CRT_SECURE_NO_WARNINGS

// Name:Wanrong Xie
// Username:201487690
// Date started:2022.3.15

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "book_management.h"
#include "library.h"
#include "global.h"
#include "user.h"


//book_management.h
char bfname[40];
char ufname[40];
FILE* bfile;
Book* bhead;
BookList* booklist;

////
// Code module for main()
// main function takes command line arguments 
// and opens the library menu
// Input: book data filename via command line
// Usage: ./library books.txt users.txt


int main(void)
{
    strcpy(bfname, "books.txt");
    strcpy(ufname, "users.txt");
    // check that correct number of command line arguments are entered    
    //if (argc != 3) {
    //    // use the error message 
    //    printf("Error\nExpected use: ./library books.txt users.txt\n");
    //    // exit the application if there is an error
    //    exit(1);
    //}
    //else {
    //    // assign command line value to filename string
    //    strcpy(bfname, argv[1]);
    //    strcpy(ufname , argv[2]);
    //}


    bhead = createbList();
    BookList* booklist = initBooklist(bhead);
    FILE* bfile = NULL;

    //int year = 0;
    //printf("��������ݣ�");
    //scanf("%d", &year);
    //find_book_by_year(year);

    search_for_books();
    //getch();

    //system("pause");
    return 0;
}